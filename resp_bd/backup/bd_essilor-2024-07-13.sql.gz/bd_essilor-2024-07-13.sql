-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: bd_essilor
-- ------------------------------------------------------
-- Server version	10.3.39-MariaDB-0+deb10u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_Almacen`
--

DROP TABLE IF EXISTS `t_Almacen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Almacen` (
  `id_almacen` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  PRIMARY KEY (`id_almacen`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Almacen`
--

LOCK TABLES `t_Almacen` WRITE;
/*!40000 ALTER TABLE `t_Almacen` DISABLE KEYS */;
INSERT INTO `t_Almacen` VALUES (1,'ELM-MDF2'),(2,'IDF5'),(3,'ELM-IDF5'),(4,'Linea Produccion Surfacing'),(5,'Linea Produccion DC');
/*!40000 ALTER TABLE `t_Almacen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Categorias`
--

DROP TABLE IF EXISTS `t_Categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Categorias` (
  `id_categoria` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(40) NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Categorias`
--

LOCK TABLES `t_Categorias` WRITE;
/*!40000 ALTER TABLE `t_Categorias` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_Categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Centro_Costos`
--

DROP TABLE IF EXISTS `t_Centro_Costos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Centro_Costos` (
  `id_centro_costos` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `num_centro_costos` varchar(30) NOT NULL,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`id_centro_costos`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Centro_Costos`
--

LOCK TABLES `t_Centro_Costos` WRITE;
/*!40000 ALTER TABLE `t_Centro_Costos` DISABLE KEYS */;
INSERT INTO `t_Centro_Costos` VALUES (1,'102520','LABS'),(2,'000','NA'),(3,'751103','Oakley'),(4,'0010123','Distribution Center'),(5,'1010101','Ingenieria'),(6,'751053','Recursos Humanos'),(7,'10102324','Distribution Center'),(8,'751779','Surfacing '),(9,'5623','Centro Costos Compras'),(10,'92029302','Coating'),(11,'8009','Purchasing'),(12,'751047','EHS'),(13,'751043','Asset Protection'),(14,'1000023','Centro Costos Finanzas '),(15,'1245133','Centro Costos Planeacion'),(16,'751815','Calidad Final Control'),(17,'1106','Logistic'),(18,'12452325','Centro costos Simulacion'),(19,'124754856','Cadena de Suministros'),(20,'159800225','Opex y Automatizacion'),(21,'751146','Customer Service'),(22,'751513','Facilities'),(23,'751891','Centro De Costos Logistica Len EOP Merge'),(24,'751051','Mantenimiento DC'),(25,'751092','Hard Coating'),(26,'751283','AR'),(27,'751323','Edning Mounting Finishing'),(28,'11454335','Centro Costos Entreamiento y CI');
/*!40000 ALTER TABLE `t_Centro_Costos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Cintas`
--

DROP TABLE IF EXISTS `t_Cintas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Cintas` (
  `id_cintas` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `num_serial` varchar(15) NOT NULL,
  `fecha_inic` date DEFAULT NULL,
  `fecha_final` date DEFAULT NULL,
  `ubicacion` varchar(20) NOT NULL,
  `comentarios` text DEFAULT NULL,
  PRIMARY KEY (`id_cintas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Cintas`
--

LOCK TABLES `t_Cintas` WRITE;
/*!40000 ALTER TABLE `t_Cintas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_Cintas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Depto`
--

DROP TABLE IF EXISTS `t_Depto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Depto` (
  `id_depto` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`id_depto`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Depto`
--

LOCK TABLES `t_Depto` WRITE;
/*!40000 ALTER TABLE `t_Depto` DISABLE KEYS */;
INSERT INTO `t_Depto` VALUES (1,'Ingenieria'),(2,'N/A'),(3,'Mantenimiento - Facilities'),(4,'Distribution Center'),(5,'Recursos Humanos'),(6,'Manufactura'),(7,'Purchasing'),(8,'Tool Room'),(9,'Laboratorio Manager'),(10,'Customer Services'),(11,'Coating Hard'),(12,'EHS'),(13,'Asset Proctection'),(14,'Finanzas'),(15,'Oakley'),(16,'Planeacion'),(17,'Departamento Calidad'),(18,'IT'),(19,'Simulacion'),(20,'Cadena de Suministros'),(21,'Opex y Automatizacion'),(22,'Logistica'),(23,'Mantenimiento - DC'),(24,'Mantenimiento LAB');
/*!40000 ALTER TABLE `t_Depto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Edo_epo`
--

DROP TABLE IF EXISTS `t_Edo_epo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Edo_epo` (
  `id_edo_epo` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`id_edo_epo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Edo_epo`
--

LOCK TABLES `t_Edo_epo` WRITE;
/*!40000 ALTER TABLE `t_Edo_epo` DISABLE KEYS */;
INSERT INTO `t_Edo_epo` VALUES (1,'Operable'),(2,'En Reparacion Con Proveedor'),(3,'Nuevo');
/*!40000 ALTER TABLE `t_Edo_epo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Empleados`
--

DROP TABLE IF EXISTS `t_Empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Empleados` (
  `id_empleado` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_ubicacion` smallint(5) unsigned NOT NULL,
  `id_puesto` smallint(5) unsigned NOT NULL,
  `id_supervisor` smallint(5) unsigned NOT NULL,
  `id_depto` smallint(5) unsigned NOT NULL,
  `id_centro_costos` smallint(5) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `ntid` varchar(20) NOT NULL,
  `correo_electronico` varchar(50) NOT NULL,
  `rol` varchar(25) DEFAULT NULL,
  `foto` varchar(100) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_empleado`),
  KEY `id_ubicacion` (`id_ubicacion`),
  KEY `id_puesto` (`id_puesto`),
  KEY `id_supervisor` (`id_supervisor`),
  KEY `id_depto` (`id_depto`),
  KEY `id_centro_costos` (`id_centro_costos`),
  CONSTRAINT `t_Empleados_ibfk_1` FOREIGN KEY (`id_ubicacion`) REFERENCES `t_Ubicacion` (`id_ubicacion`) ON UPDATE CASCADE,
  CONSTRAINT `t_Empleados_ibfk_2` FOREIGN KEY (`id_puesto`) REFERENCES `t_Puesto` (`id_puesto`) ON UPDATE CASCADE,
  CONSTRAINT `t_Empleados_ibfk_3` FOREIGN KEY (`id_supervisor`) REFERENCES `t_Supervisor` (`id_supervisor`) ON UPDATE CASCADE,
  CONSTRAINT `t_Empleados_ibfk_4` FOREIGN KEY (`id_depto`) REFERENCES `t_Depto` (`id_depto`) ON UPDATE CASCADE,
  CONSTRAINT `t_Empleados_ibfk_5` FOREIGN KEY (`id_centro_costos`) REFERENCES `t_Centro_Costos` (`id_centro_costos`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Empleados`
--

LOCK TABLES `t_Empleados` WRITE;
/*!40000 ALTER TABLE `t_Empleados` DISABLE KEYS */;
INSERT INTO `t_Empleados` VALUES (1,22,2,27,18,2,'I T','Sistemas','000','it_elem@essilorluxottica.id',NULL,'vistas/img/empleados/000/641.jpg','2024-04-11 13:18:16'),(6,3,1,1,1,1,'Juan','Ortiz','1010','correo@correo1.com',NULL,'vistas/img/empleados/1010/629.jpg','2024-04-11 13:19:35'),(10,3,1,1,1,1,'Ulises','Montiel','6050','correo3@corre.com',NULL,'vistas/img/empleados/6050/279.png','2024-04-11 20:15:16'),(11,5,3,3,3,3,'Deisy Jannet','De Leon De Cardenas','00010101','leoncard@essilorluxottica.id',NULL,'vistas/img/empleados/00010101/371.jpg','2024-05-12 11:09:54'),(12,3,4,4,4,4,'Annel Brizeida','Espinoza Gutierrez','50198','annel.espinoza@essilorluxottica.id',NULL,'vistas/img/empleados/00010102/526.jpg','2024-05-12 17:45:39'),(17,7,5,5,1,5,'Maria Eugenia','Galvan Solis','80199','m.eugeniaS@essilorluxottica.id',NULL,'vistas/img/empleados/029384/690.jpg','2024-05-15 06:54:44'),(19,8,6,6,5,6,'Srah Elizabeth','Castillejos Brisson','900087','scastillejos@essilorusa.com',NULL,'vistas/img/empleados/900087/449.jpg','2024-05-19 16:14:32'),(20,3,8,4,4,7,'Patricio ','Lechon','1010123','patricio.lechon@essilorusa.com',NULL,'vistas/img/empleados/1010123/364.jpg','2024-05-22 06:12:25'),(21,10,7,8,1,8,'Linea Produccion','Surfacing','1000001','surfacing@essilorusa.com',NULL,'vistas/img/empleados/1000001/937.png','2024-05-22 15:01:09'),(22,11,9,10,4,4,'Jazmin Anai','Ruelas','50125','jazmin.ruelas@essilorluxottica.id',NULL,'vistas/img/empleados/9092392/212.jpg','2024-05-22 15:57:35'),(24,8,10,6,5,6,'Jose','Leyva','50189','jose.leyva@essilorusa.com',NULL,'vistas/img/empleados/56896/820.jpg','2024-05-26 16:21:45'),(25,13,11,12,7,9,'Cecilia ','Morales Gaspar','50191','cecilia.morales@essilorusa.com',NULL,'vistas/img/empleados/50191/609.jpg','2024-05-26 16:48:58'),(26,8,12,13,5,6,'Jazmin','Hernandez','50099','yasmin.hernandez@essilorusa.com',NULL,'vistas/img/empleados/50099/492.jpg','2024-05-26 17:33:43'),(27,3,13,2,4,4,'Adrian','Rodriguez','3783723','adrian.rodriguez@essilorusa.com',NULL,'vistas/img/empleados/3783723/976.jpg','2024-05-29 07:58:16'),(28,6,14,8,8,3,'Christian ','Mondaca Anaya','50173','mondacac@essilorluxottica.id',NULL,'vistas/img/empleados/50173/473.jpg','2024-06-09 13:21:30'),(29,3,15,14,9,4,'Paola Carolina','Marquez Fletes','50105','carolina.marzquez@essilorluxottica.id',NULL,'vistas/img/empleados/50105/748.jpg','2024-06-09 16:34:04'),(30,3,15,14,10,4,'Perla Sarai','Merida Rodriguez','50143','sarai.merida@essilorusa.com',NULL,'vistas/img/empleados/50143/393.jpg','2024-06-09 16:42:42'),(32,15,16,15,11,10,'Sandi Daniel','Hernandez Brito','157','sandi.hernandezB@essilorluxottica.id',NULL,'vistas/img/empleados/157/966.jpg','2024-06-09 16:57:34'),(33,12,17,16,1,5,'Lazaro','Barraza Gamez','50098','lazaro.barraza@essilorusa.com',NULL,'vistas/img/empleados/50098/925.jpg','2024-06-09 17:07:09'),(34,13,11,17,7,11,'Pamela Joselyn','Coca Cesar','50032','pamela.coca@essilorusa.com',NULL,'vistas/img/empleados/50032/162.jpg','2024-06-09 17:14:45'),(35,16,18,18,12,12,'Aaron Alexis','Ceron Navarro','50116','cerona@essilorusa.com',NULL,'vistas/img/empleados/50116/380.jpg','2024-06-09 17:22:35'),(36,13,19,17,7,9,'Enrique','De Los Rios','50192','enrique_rios@essilorusa.com',NULL,'vistas/img/empleados/50192/707.jpg','2024-06-23 11:40:50'),(37,3,20,19,4,7,'Edgar','Silva ','1','esilva@essilorusa.com',NULL,'vistas/img/empleados/1/430.jpg','2024-06-23 16:32:08'),(38,5,14,20,8,3,'Luis Edmundo','Morin Mato','50178','edmund.marin@essilorusa.com',NULL,'vistas/img/empleados/50178/135.jpg','2024-06-23 16:55:53'),(40,8,21,6,5,6,'Martha Delia','Beltran','50203','mbeltran@essilorusa.com',NULL,'vistas/img/empleados/50203/806.jpg','2024-06-23 17:04:11'),(41,17,22,21,13,13,'Jose Luis','Prieto','5009','Jose.Prieto@essilorluxottica.id',NULL,'vistas/img/empleados/56245/822.jpg','2024-06-23 17:20:54'),(42,18,23,22,14,14,'Cesia Alejandra','Saenzpardo','50202','casaenzpardo@essilorusa.com',NULL,'vistas/img/empleados/50202/287.jpg','2024-07-01 03:47:00'),(43,8,24,23,5,6,'Elizabeth Alejandra','Morales Munoz','256204','e.moralesm@essilorusa.com',NULL,'vistas/img/empleados/256204/961.jpg','2024-07-01 04:01:34'),(44,19,25,20,15,3,'Jonathan ','Martinez','50177','j.martinezvega@essilorusa.com',NULL,'vistas/img/empleados/50177/521.jpg','2024-07-01 04:16:45'),(45,20,26,24,16,15,'Isahi','Hernandez','900078','isahi.hernandez@essilorusa.com',NULL,'vistas/img/empleados/900078/948.jpg','2024-07-01 04:31:53'),(46,21,27,25,17,16,'Roberto','Lopez Acebo','50775','lopezacr@essilorluxottica.id',NULL,'vistas/img/empleados/50775/541.jpg','2024-07-02 04:06:02'),(47,17,28,26,13,13,'Rene','Aguilar ','50045','rene.aguilar@essilorusa.com',NULL,'vistas/img/empleados/50045/674.jpg','2024-07-02 04:47:21'),(48,23,29,28,19,17,'Adan','Rosas Contreras','50129','adan.rosas@essilorusa.com',NULL,'vistas/img/empleados/50129/773.jpg','2024-07-04 01:07:49'),(49,23,29,28,19,18,'Daila Arsil','Naval Segura ','50121','dalia.naval@essilorluxottica.id',NULL,'vistas/img/empleados/7517/548.jpg','2024-07-08 04:14:56'),(50,24,30,29,20,19,'Luis Entique','Galan Knoell','50092','luis.galan@essilorusa.com',NULL,'vistas/img/empleados/50092/150.jpg','2024-07-08 04:28:32'),(51,25,31,30,21,20,'Sergio Manuel','Sauceda Raygoza','50103','sergio.sauceda@essilorusa.com',NULL,'vistas/img/empleados/50103/993.jpg','2024-07-08 04:38:34'),(52,21,32,6,17,16,'Jordan Alonso','Alonzo Leon','50093','jordan.alonzo@essilorusa.com',NULL,'vistas/img/empleados/50093/964.jpg','2024-07-08 04:46:58'),(53,26,33,14,10,21,'Zulma Angelica','Montiel Diaz','50083','zmontiel@essilorusa.com',NULL,'vistas/img/empleados/50083/956.jpg','2024-07-08 05:00:50'),(54,30,34,32,3,22,'Maricruz','Arreguin Lona','50117','maricruz.arreguin@essilorusa.com',NULL,'vistas/img/empleados/50117/643.jpg','2024-07-09 04:17:40'),(55,3,35,4,4,7,'Jose Fernando','Irazaba Manriques','50081','fernando.irazaba@essilorusa.com',NULL,'vistas/img/empleados/50081/986.jpg','2024-07-09 04:25:59'),(56,31,36,33,22,23,'Felix','Lira','50146','felixl@essilorluxottica.id',NULL,'vistas/img/empleados/50146/126.jpg','2024-07-09 04:50:14'),(57,3,37,3,23,24,'Jonatan','Espinoza','50060','jonatan.espinoza@essilorusa.com',NULL,'vistas/img/empleados/50060/525.jpg','2024-07-09 05:00:00'),(58,17,9,34,13,13,'Jonathan Nicolas','Resendiz Villalobos','50097','jonathan.resendiz@essilorusa.com',NULL,'vistas/img/empleados/50097/484.jpg','2024-07-09 05:10:53'),(59,32,37,35,24,24,'David','Lopez','50010253','david.lopez@essilorusa.com',NULL,'vistas/img/empleados/50010253/933.jpg','2024-07-09 05:20:39'),(60,8,10,6,5,6,'Erika','Campos','500148','erika.campos@essilorusa.com',NULL,'vistas/img/empleados/500148/678.jpg','2024-07-10 04:31:05'),(61,17,38,34,13,13,'Angelica ','Ramirez','254562','angelica.ramirez@essilorusa.com',NULL,'vistas/img/empleados/254562/448.jpg','2024-07-10 04:38:57'),(62,12,39,16,1,5,'Jhon ','Guerra','00001','joguerra@essilorusa.com',NULL,'vistas/img/empleados/00001/856.jpg','2024-07-10 04:53:50'),(63,17,28,34,13,13,'Isaac','Morales','50088','isaac.morales@essilorusa.com',NULL,'vistas/img/empleados/50088/545.jpg','2024-07-10 04:59:18'),(64,21,27,16,17,16,'Gabriel Jesus','Zamora Vega','50037','gabriel.zamora@essilorusa.com',NULL,'vistas/img/empleados/50037/337.jpg','2024-07-10 05:26:59'),(65,33,40,38,10,28,'Diana L','Audelo','50075','diana.audelo@essilorusa.com',NULL,'vistas/img/empleados/50075/904.jpg','2024-07-10 05:36:09'),(66,8,10,39,5,6,'Yesica','Feliz G','10225','yfelix@essilorusa.com',NULL,'vistas/img/empleados/10225/958.jpg','2024-07-10 05:43:57');
/*!40000 ALTER TABLE `t_Empleados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Estatus`
--

DROP TABLE IF EXISTS `t_Estatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Estatus` (
  `id_estatus` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(20) NOT NULL,
  PRIMARY KEY (`id_estatus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Estatus`
--

LOCK TABLES `t_Estatus` WRITE;
/*!40000 ALTER TABLE `t_Estatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_Estatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Linea`
--

DROP TABLE IF EXISTS `t_Linea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Linea` (
  `id_linea` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_linea`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Linea`
--

LOCK TABLES `t_Linea` WRITE;
/*!40000 ALTER TABLE `t_Linea` DISABLE KEYS */;
INSERT INTO `t_Linea` VALUES (1,'Sin Linea'),(2,'Finish Estacion 3 Sort'),(3,'Mantto Oakley'),(4,'Smart Table'),(5,'Linea 4 A'),(6,'Recibos'),(7,'VAS');
/*!40000 ALTER TABLE `t_Linea` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Marca`
--

DROP TABLE IF EXISTS `t_Marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Marca` (
  `id_marca` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Marca`
--

LOCK TABLES `t_Marca` WRITE;
/*!40000 ALTER TABLE `t_Marca` DISABLE KEYS */;
INSERT INTO `t_Marca` VALUES (1,'Dell'),(2,'HP'),(3,'Zebra'),(4,'Better Pack'),(5,'Motorola'),(6,'Satisloh '),(7,'Symbol'),(8,'Apple'),(9,'Mettler Toledo'),(10,'Datalogic'),(11,'Weber'),(13,'Delta'),(14,'APC'),(15,'Logitech');
/*!40000 ALTER TABLE `t_Marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Modelo`
--

DROP TABLE IF EXISTS `t_Modelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Modelo` (
  `id_modelo` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_modelo`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Modelo`
--

LOCK TABLES `t_Modelo` WRITE;
/*!40000 ALTER TABLE `t_Modelo` DISABLE KEYS */;
INSERT INTO `t_Modelo` VALUES (1,'Latitude 5440'),(2,'Elitebook 870'),(3,'Latitute 3440'),(4,'LaserJet Enterprise M507'),(5,'ZD 621'),(6,'E2222H'),(7,'KB216'),(8,'MS1161'),(9,'Optiplex Micro 7010'),(10,'KB245'),(11,'MS1161L'),(12,'BP555eSA'),(13,'Moto g53 '),(14,'Multiplex 2'),(15,'SBRE'),(16,'Iphone 13'),(17,'BC'),(18,'Magellan 3400'),(19,'Slow VAS ZE523-RH'),(20,'Iphone 15'),(21,'P2222H'),(22,'DW19S'),(23,'Dock WD15'),(24,'G71 5G'),(25,'ZT 231'),(26,'DA130PE1-00'),(27,'LA45NM140'),(28,'LA90PM130'),(29,'ADP-50YHB'),(30,'LOH24A'),(31,'KM5221W'),(32,'KM300CLTN'),(33,'H151'),(34,'Laser Enterprise M612dn'),(35,'Latitude 5430'),(36,'Precision 3581'),(37,'LA65NM170'),(38,'BR700G');
/*!40000 ALTER TABLE `t_Modelo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Notas`
--

DROP TABLE IF EXISTS `t_Notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Notas` (
  `id_nota` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` smallint(5) unsigned NOT NULL,
  `nombre_nota` varchar(120) NOT NULL,
  `descripcion_nota` text DEFAULT NULL,
  `fecha` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_nota`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `t_Notas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `t_Usuarios` (`id_usuario`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Notas`
--

LOCK TABLES `t_Notas` WRITE;
/*!40000 ALTER TABLE `t_Notas` DISABLE KEYS */;
INSERT INTO `t_Notas` VALUES (4,2,'Pruebas','Pruebas							       \r\n							','2024-05-12');
/*!40000 ALTER TABLE `t_Notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Periferico`
--

DROP TABLE IF EXISTS `t_Periferico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Periferico` (
  `id_periferico` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_periferico`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Periferico`
--

LOCK TABLES `t_Periferico` WRITE;
/*!40000 ALTER TABLE `t_Periferico` DISABLE KEYS */;
INSERT INTO `t_Periferico` VALUES (1,'Laptop','2024-04-11 12:50:57'),(2,'Desktop','2024-04-11 13:23:47'),(3,'Impresora','2024-05-15 07:22:21'),(4,'Teclado','2024-05-15 07:23:56'),(5,'Raton','2024-05-15 07:24:18'),(6,'Monitor','2024-05-15 07:24:32'),(7,'Escaner','2024-05-15 07:24:45'),(8,'Telefono','2024-05-18 18:39:12'),(9,'Dispensador Cinta Cajas','2024-05-22 08:07:32'),(10,'Maquina pulidora micas','2024-05-22 14:41:18'),(11,'Escaner Tipo Pistola','2024-05-22 17:10:36'),(12,'Pesa','2024-05-27 07:06:50'),(13,'Docking Station','2024-07-03 02:13:09'),(14,'Cargador de Laptop','2024-07-09 21:12:28'),(15,'AC Docking','2024-07-09 21:15:53'),(16,'AC Laptop Tipo C','2024-07-09 22:13:47'),(17,'AC Laptop Tipo 45W','2024-07-09 22:27:24'),(18,'AC Monitor EVO 50W','2024-07-09 22:47:53'),(19,'Backp UPS','2024-07-09 23:08:23'),(20,'Kit Mantenimiento','2024-07-09 23:14:27'),(21,'Teclado Raton Inhala','2024-07-09 23:28:59'),(22,'Teclado Raton Combo','2024-07-09 23:46:45'),(23,'Headset','2024-07-10 00:00:28'),(24,'AC Laptop Tipo 90W','2024-07-11 22:58:59');
/*!40000 ALTER TABLE `t_Periferico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_PlanTelefonia`
--

DROP TABLE IF EXISTS `t_PlanTelefonia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_PlanTelefonia` (
  `id_plan_tel` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id_plan_tel`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_PlanTelefonia`
--

LOCK TABLES `t_PlanTelefonia` WRITE;
/*!40000 ALTER TABLE `t_PlanTelefonia` DISABLE KEYS */;
INSERT INTO `t_PlanTelefonia` VALUES (1,'SP3 2 Gb de navegacion'),(2,'TPE CONT VPN 3 DD 24');
/*!40000 ALTER TABLE `t_PlanTelefonia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Productos`
--

DROP TABLE IF EXISTS `t_Productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Productos` (
  `id_producto` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_almacen` smallint(5) unsigned NOT NULL,
  `id_edo_epo` smallint(5) unsigned NOT NULL,
  `id_marca` smallint(5) unsigned NOT NULL,
  `id_modelo` smallint(5) unsigned NOT NULL,
  `id_linea` smallint(5) unsigned NOT NULL,
  `id_ubicacion` smallint(5) unsigned NOT NULL,
  `id_periferico` smallint(5) unsigned NOT NULL,
  `id_empleado` smallint(5) unsigned DEFAULT 1,
  `id_telefonia` smallint(5) unsigned NOT NULL,
  `id_plan_tel` smallint(5) unsigned NOT NULL,
  `num_tel` varchar(25) DEFAULT NULL,
  `cuenta` varchar(45) DEFAULT NULL,
  `direcc_mac_tel` varchar(20) DEFAULT NULL,
  `imei_tel` varchar(30) DEFAULT NULL,
  `nomenclatura` varchar(45) DEFAULT NULL,
  `num_serie` varchar(45) DEFAULT NULL,
  `imagen_producto` varchar(100) NOT NULL,
  `stock` smallint(5) unsigned DEFAULT 0,
  `precio_compra` decimal(10,2) DEFAULT NULL,
  `precio_venta` decimal(10,2) DEFAULT NULL,
  `cuantas_veces` tinyint(4) DEFAULT NULL,
  `asignado` char(1) DEFAULT 'N',
  `fecha_arribo` datetime NOT NULL DEFAULT current_timestamp(),
  `edo_tel` varchar(15) DEFAULT NULL,
  `num_ip` varchar(20) DEFAULT NULL,
  `comentarios` text DEFAULT NULL,
  `especificaciones` text DEFAULT NULL,
  `asset` varchar(15) DEFAULT NULL,
  `loftware` varchar(10) DEFAULT NULL,
  `area` varchar(20) DEFAULT NULL,
  `npa` varchar(15) DEFAULT NULL,
  `idf` varchar(5) DEFAULT NULL,
  `patch_panel` varchar(5) DEFAULT NULL,
  `puerto` varchar(5) DEFAULT NULL,
  `funcion` varchar(20) DEFAULT NULL,
  `jls` varchar(15) DEFAULT NULL,
  `qdc` varchar(15) DEFAULT NULL,
  `linea` varchar(15) DEFAULT NULL,
  `estacion` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `id_almacen` (`id_almacen`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_edo_epo` (`id_edo_epo`),
  KEY `id_marca` (`id_marca`),
  KEY `id_modelo` (`id_modelo`),
  KEY `id_linea` (`id_linea`),
  KEY `id_ubicacion` (`id_ubicacion`),
  KEY `id_periferico` (`id_periferico`),
  KEY `id_telefonia` (`id_telefonia`),
  KEY `id_plan_tel` (`id_plan_tel`),
  CONSTRAINT `t_Productos_ibfk_1` FOREIGN KEY (`id_almacen`) REFERENCES `t_Almacen` (`id_almacen`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_10` FOREIGN KEY (`id_plan_tel`) REFERENCES `t_PlanTelefonia` (`id_plan_tel`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `t_Empleados` (`id_empleado`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_3` FOREIGN KEY (`id_edo_epo`) REFERENCES `t_Edo_epo` (`id_edo_epo`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_4` FOREIGN KEY (`id_marca`) REFERENCES `t_Marca` (`id_marca`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_5` FOREIGN KEY (`id_modelo`) REFERENCES `t_Modelo` (`id_modelo`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_6` FOREIGN KEY (`id_linea`) REFERENCES `t_Linea` (`id_linea`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_7` FOREIGN KEY (`id_ubicacion`) REFERENCES `t_Ubicacion` (`id_ubicacion`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_8` FOREIGN KEY (`id_periferico`) REFERENCES `t_Periferico` (`id_periferico`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_9` FOREIGN KEY (`id_telefonia`) REFERENCES `t_Telefonia` (`id_telefonia`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=330 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Productos`
--

LOCK TABLES `t_Productos` WRITE;
/*!40000 ALTER TABLE `t_Productos` DISABLE KEYS */;
INSERT INTO `t_Productos` VALUES (4,1,1,2,2,1,3,2,1,1,1,'0','','','','MXD2564AASD','2564AASD','vistas/img/productos/varios/831.jpg',2,600.00,600.00,1,'N','2024-04-11 13:27:11','NO Aplica','','Se encuentran con danos fisicos',NULL,'','',NULL,'','','','','','','',NULL,''),(5,1,1,2,2,1,3,1,10,1,1,'0','','','','MXL938547HEJR','938547HEJR','vistas/img/productos/varios/174.jpg',0,950.00,950.00,1,'N','2024-04-11 20:11:38','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(6,2,3,1,3,1,5,1,11,1,1,'0','','','','MXLHQ7K5Y3','HQ7K5Y3','vistas/img/productos/varios/514.png',0,900.00,900.00,1,'N','2024-05-12 11:16:52','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(7,3,3,1,1,1,3,1,12,1,1,'0','','','','MXL42F0VW3','42F0VW3','vistas/img/productos/varios/636.png',0,1000.00,1000.00,1,'N','2024-05-12 17:48:42','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(10,3,3,3,5,4,3,3,20,1,1,'0','','','','','D7J240306103','vistas/img/productos/varios/753.jpg',0,500.00,500.00,4,'N','2024-05-19 07:47:58','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'Est 6'),(11,3,3,2,4,4,3,3,20,1,1,'0','','','','','PHCCR2602T','vistas/img/productos/varios/881.jpg',0,550.00,550.00,3,'N','2024-05-19 07:55:03','NO Aplica','10.107.68.104','',NULL,'','',NULL,'','2','C','12','','','',NULL,'17'),(12,3,3,1,1,1,8,1,19,1,1,'0','','','','','L98VYTW3','vistas/img/productos/varios/824.jpg',0,1000.00,1000.00,1,'N','2024-05-19 16:18:29','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(13,5,3,1,9,4,9,2,20,1,1,'0','','','','MXD4MRY5X3','4MRY5X3','vistas/img/productos/varios/451.jpg',0,500.00,500.00,4,'N','2024-05-20 07:40:25','NO Aplica','','',NULL,'','',NULL,'','IDF2','C','14','','','',NULL,'6'),(14,5,3,1,10,4,3,4,20,1,1,'0','','','','','PRC00-2AT-A24E-A01','vistas/img/productos/varios/778.jpg',0,10.00,10.00,4,'N','2024-05-20 07:48:53','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'6'),(15,3,3,1,11,4,9,5,20,1,1,'0','','','','','L0300-2AH-0BII','vistas/img/productos/varios/454.jpg',0,10.00,10.00,4,'N','2024-05-20 08:07:57','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(16,5,3,1,6,4,9,6,20,1,1,'0','','','','','9G2CJT3','vistas/img/productos/varios/163.jpg',0,120.00,120.00,4,'N','2024-05-22 06:32:10','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(17,3,1,5,13,1,6,8,1,1,2,'6646282796','','FC:B9:DF:50:93:DB','352295694826058','','','vistas/img/productos/varios/497.jpg',1,220.00,220.00,NULL,'N','2024-05-22 12:03:08','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(18,4,3,6,14,5,10,10,21,1,1,'0','','','','275','39594','vistas/img/productos/varios/201.jpg',0,1.00,1.00,1,'N','2024-05-22 14:55:33','NO Aplica','','',NULL,'','',NULL,'','4','G','37','','','',NULL,'Pulen'),(19,3,3,1,9,6,11,2,22,1,1,'0','','','','MXDHZXWWX3','HZXWWX3','vistas/img/productos/varios/932.jpg',0,500.00,500.00,4,'N','2024-05-22 16:04:19','NO Aplica','','',NULL,'','',NULL,'','3','A','6','','','',NULL,'3'),(20,5,3,4,12,4,3,9,20,1,1,'0','','','','','5ESA2123077','vistas/img/productos/varios/564.jpg',0,2220.00,2220.00,2,'N','2024-05-22 16:25:53','NO Aplica','','',NULL,'','',NULL,'','','','','RellenoPapel','','',NULL,'6'),(21,5,3,1,6,6,11,6,22,1,1,'0','','','','','97RBJT3','vistas/img/productos/varios/307.jpg',0,120.00,120.00,4,'N','2024-05-22 16:42:03','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'3'),(22,5,3,1,11,6,11,5,22,1,1,'0','','','','','LO300-2AP-060B','vistas/img/productos/varios/316.jpg',0,5.00,5.00,4,'N','2024-05-22 16:49:57','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'3'),(23,5,3,1,10,6,11,4,22,1,1,'0','','','','','PRC00-32S-A4BY-A01','vistas/img/productos/varios/971.jpg',0,10.00,10.00,3,'N','2024-05-22 16:59:31','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'3'),(24,5,3,2,4,6,11,3,22,1,1,'0','','','','','PHCCR2603D','vistas/img/productos/varios/427.jpg',0,550.00,550.00,2,'N','2024-05-22 17:04:52','NO Aplica','10.107.71.16','',NULL,'','',NULL,'','3','A','5','','','',NULL,'3'),(25,5,3,7,15,6,11,11,22,1,1,'0','','','','','Z4712N','vistas/img/productos/varios/518.jpg',0,200.00,200.00,1,'N','2024-05-22 17:15:34','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'3'),(26,3,1,5,13,1,8,8,24,1,1,'0','','','','','352295694825191','vistas/img/productos/varios/762.jpg',0,220.00,220.00,1,'N','2024-05-26 16:24:53','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(27,3,3,8,16,1,12,8,17,1,1,'6646282804','','','351835927178602','','27178602','vistas/img/productos/varios/917.jpg',0,700.00,700.00,1,'N','2024-05-26 16:38:34','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(28,3,3,1,1,1,13,1,25,1,1,'0','','','','MXL59L0VW3','59L0VW3','vistas/img/productos/varios/820.jpg',0,1000.00,1000.00,1,'N','2024-05-26 16:50:48','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(29,3,3,1,1,1,12,1,17,1,1,'0','','','','MXD2VD0VW3','2VD0VW3','vistas/img/productos/varios/120.jpg',0,1000.00,1000.00,1,'N','2024-05-26 17:22:08','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(30,5,3,9,17,1,3,12,20,1,1,'0','','','','','67793776BA','vistas/img/productos/varios/349.jpg',0,800.00,800.00,1,'N','2024-05-27 07:08:59','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'6'),(31,5,3,10,18,4,3,7,20,1,1,'0','','','','','4948571A','vistas/img/productos/varios/707.jpg',0,380.00,380.00,2,'N','2024-05-27 07:24:25','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'8'),(32,3,3,11,19,4,3,3,20,1,1,'0','','','','','FLAG0078','vistas/img/productos/varios/791.jpg',0,8000.00,8000.00,2,'N','2024-05-27 07:38:51','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'8'),(33,3,3,1,9,4,3,2,20,1,1,'0','','','','MXDDW37CW3','DW37CW3','vistas/img/productos/varios/954.jpg',0,500.00,500.00,2,'N','2024-05-27 07:46:22','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'8'),(34,3,3,1,6,4,3,6,20,1,1,'0','','','','','2BA-C3JX-A03','vistas/img/productos/varios/847.jpg',0,120.00,120.00,2,'N','2024-05-27 07:51:16','NO Aplica','','Serial Completo: CN-0MVCKH-FCC00-2BA-C3JX-A03',NULL,'','',NULL,'','','','','','','',NULL,'8'),(35,5,3,1,10,4,3,4,20,1,1,'0','','','','MXDDW37CW3','331-03WZ-A02','vistas/img/productos/varios/549.jpg',0,10.00,10.00,1,'N','2024-05-27 07:54:54','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'8'),(36,5,3,1,8,4,3,5,20,1,1,'0','','','','MXDDW37CW3','L0300-2AP-05ZM','vistas/img/productos/varios/920.jpg',0,5.00,5.00,1,'N','2024-05-27 07:57:39','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'8'),(37,5,3,11,19,4,3,3,20,1,1,'0','','','','','FLAG00079','vistas/img/productos/varios/890.jpg',0,8000.00,8000.00,2,'N','2024-05-28 07:53:00','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'10'),(38,5,3,1,6,4,3,6,20,1,1,'0','','','','','FCC00-2BA-AC4X-A03','vistas/img/productos/varios/723.jpg',0,120.00,120.00,1,'N','2024-05-29 06:56:16','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'10'),(39,5,3,1,9,4,3,2,20,1,1,'0','','','','MXD8MTL7Y3','8MTL7Y3','vistas/img/productos/varios/259.jpg',0,500.00,500.00,1,'N','2024-05-29 07:01:50','NO Aplica','','',NULL,'','',NULL,'','IDF2','C','18','','','',NULL,'10'),(40,5,3,1,7,4,3,4,1,1,1,'0','','','','','29K-A61W-A01','vistas/img/productos/varios/623.jpg',1,10.00,10.00,NULL,'N','2024-05-29 07:04:27','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'10'),(41,4,3,1,8,4,3,5,20,1,1,'0','','','','MX8MTL7Y3','LO300-29G-0B01','vistas/img/productos/varios/802.jpg',0,5.00,5.00,1,'N','2024-05-29 07:09:44','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'10'),(42,5,3,10,18,4,3,7,20,1,1,'0','','','','','9384KDJSKD','vistas/img/productos/varios/704.jpg',0,380.00,380.00,1,'N','2024-05-29 07:20:35','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'10'),(43,5,3,11,19,4,3,3,1,1,1,'0','','','','','FLAG0079','vistas/img/productos/varios/728.jpg',1,8000.00,8000.00,NULL,'N','2024-05-29 07:42:48','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'10'),(44,5,3,1,7,4,3,4,1,1,1,'0','','','','MXD8XXWWX3','PRC00-32S-A4CS-A01','vistas/img/productos/varios/115.jpg',1,10.00,10.00,NULL,'N','2024-05-29 08:05:19','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'12'),(45,3,3,1,1,1,6,1,28,1,1,'0','','','','MXLCC70VW3','CC70VW3','vistas/img/productos/varios/468.jpg',0,1000.00,1000.00,1,'N','2024-06-09 14:28:52','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(46,3,3,1,1,1,3,1,29,1,1,'0','','','','MXESL15019','2MVK5X3','vistas/img/productos/varios/302.jpg',0,1148.00,1148.00,1,'N','2024-06-09 16:26:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(47,3,3,1,1,1,3,1,30,1,1,'0','','','','MXLC5DL5X3','C5DL5X3','vistas/img/productos/varios/259.jpg',0,1000.00,1000.00,1,'N','2024-06-09 16:44:40','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(48,3,3,1,1,1,15,1,32,1,1,'0','','','','MXESL15013','7SVK5X3','vistas/img/productos/varios/422.jpg',0,1148.00,1148.00,1,'N','2024-06-09 17:00:40','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(49,3,3,1,1,1,12,1,33,1,1,'0','','','','MXESL15033','JRGHTT3','vistas/img/productos/varios/116.jpg',0,1148.00,1148.00,1,'N','2024-06-09 17:08:36','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(50,3,3,1,1,1,13,1,34,1,1,'0','','','','MXESL15036','FRKL5X3','vistas/img/productos/varios/965.jpg',0,1148.00,1148.00,1,'N','2024-06-09 17:17:49','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(51,3,3,1,1,1,16,1,35,1,1,'0','','','','MXESL15031','BSNK5X3','vistas/img/productos/varios/730.jpg',0,1148.00,1148.00,1,'N','2024-06-09 17:23:47','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(52,3,3,1,1,1,13,1,36,1,1,'0','','','','','98VYT3W3','vistas/img/productos/varios/340.jpg',0,1000.00,1000.00,1,'N','2024-06-23 16:15:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(53,3,1,5,13,1,8,8,26,1,1,'6634079453','','','352295695947861','','ZY22HLSHQW','vistas/img/productos/varios/776.jpg',0,4309.48,4309.48,1,'N','2024-06-23 16:26:03','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(54,3,3,1,1,1,3,1,37,1,1,'0','','','','','5R9K5X3','vistas/img/productos/varios/690.jpg',0,1000.00,1000.00,1,'N','2024-06-23 16:33:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(55,3,3,1,1,1,5,1,38,1,1,'0','','','','','7VD0VW3','vistas/img/productos/varios/727.jpg',0,1000.00,1000.00,1,'N','2024-06-23 16:57:40','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(56,3,3,1,1,1,8,1,1,1,1,'0','','','','','BTD0VW3','vistas/img/productos/varios/179.jpg',1,1000.00,1000.00,NULL,'N','2024-06-23 17:05:21','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(57,3,3,1,1,1,8,1,40,1,1,'0','','','','','98HK5X3','vistas/img/productos/varios/850.jpg',0,1000.00,1000.00,1,'N','2024-06-23 17:06:41','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(58,3,3,1,1,1,8,1,40,1,1,'0','','','','','BVD0VW3','vistas/img/productos/varios/818.jpg',0,1000.00,1000.00,1,'N','2024-06-23 17:10:15','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(59,3,1,8,20,1,17,8,41,1,2,'0','','','','','928302939EWR','vistas/img/productos/varios/804.jpg',0,1170.00,1170.00,1,'N','2024-06-23 17:23:30','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(60,3,3,1,1,1,18,1,42,1,1,'0','','','','','5TD0VW3','vistas/img/productos/varios/155.jpg',0,1000.00,1000.00,1,'N','2024-07-01 03:49:05','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(61,3,3,1,1,1,8,1,43,1,1,'0','','','','','GR7K5Y3','vistas/img/productos/varios/682.jpg',0,1000.00,1000.00,1,'N','2024-07-01 04:04:26','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(62,3,3,1,1,1,19,1,44,1,1,'0','','','','','GC70VW3','vistas/img/productos/varios/439.jpg',0,1000.00,1000.00,1,'N','2024-07-01 04:19:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(63,3,3,5,13,1,19,8,44,1,1,'6634079457','','','','','ZY22HLSHGD','vistas/img/productos/varios/442.jpg',0,240.00,240.00,1,'N','2024-07-01 04:21:47','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(64,3,3,1,1,1,19,1,45,1,1,'0','','','','','JF415Y3','vistas/img/productos/varios/740.jpg',0,846.00,843.00,1,'N','2024-07-01 04:33:04','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(65,3,3,1,1,1,17,1,41,1,1,'0','','','','','6VD0VW3','vistas/img/productos/varios/382.jpg',0,1000.00,1000.00,1,'N','2024-07-02 03:52:47','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(66,3,3,1,1,1,21,1,46,1,1,'0','','','','MXLJVD0VW3','JVD0VW3','vistas/img/productos/varios/663.jpg',0,850.00,850.00,1,'N','2024-07-02 04:08:25','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(67,3,3,1,1,1,17,1,47,1,1,'0','','','','','FVHK5X3','vistas/img/productos/varios/980.jpg',0,1000.00,1000.00,1,'N','2024-07-02 04:48:43','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(68,3,3,1,21,1,22,6,1,1,1,'0','','','','','JMGF9N3','vistas/img/productos/varios/267.jpg',0,170.00,170.00,2,'N','2024-07-03 01:54:51','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(69,3,3,1,21,1,22,6,1,1,1,'0','','','','','61C09N3','vistas/img/productos/varios/306.jpg',0,170.00,170.00,1,'N','2024-07-03 02:05:41','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(70,3,3,1,22,1,22,13,1,1,1,'0','','','','','DXHWFV3','vistas/img/productos/varios/417.jpg',0,230.00,230.00,1,'N','2024-07-03 02:18:20','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(71,3,3,1,22,1,22,13,1,1,1,'0','','','','','DT6XFV3','vistas/img/productos/varios/830.jpg',0,230.00,230.00,1,'N','2024-07-03 02:25:22','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(72,3,3,1,21,1,22,6,1,1,1,'0','','','','','G0909N3','vistas/img/productos/varios/305.jpg',0,170.00,170.00,1,'N','2024-07-03 02:26:50','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(73,3,3,1,23,1,22,13,1,1,1,'0','','','','','888274201A06','vistas/img/productos/varios/407.jpg',0,300.00,300.00,1,'N','2024-07-03 23:05:15','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(74,3,3,1,21,1,22,6,1,1,1,'0','','','','','8XW29N3','vistas/img/productos/varios/735.jpg',0,180.00,180.00,1,'N','2024-07-03 23:09:59','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(75,3,3,1,21,1,22,6,1,1,1,'0','','','','','2MX29N3','vistas/img/productos/varios/968.jpg',0,170.00,170.00,1,'N','2024-07-03 23:12:59','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(76,3,3,1,22,1,22,13,1,1,1,'0','','','','','3YBTHV3','vistas/img/productos/varios/720.jpg',0,300.00,300.00,1,'N','2024-07-03 23:14:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(77,3,2,1,1,1,22,1,1,1,1,'0','','','','','3SGHTT3','vistas/img/productos/varios/445.jpg',1,1000.00,1000.00,NULL,'N','2024-07-03 23:21:24','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(78,3,3,1,1,1,22,1,1,1,1,'0','','','','','10F0VW3','vistas/img/productos/varios/775.jpg',0,1000.00,1000.00,1,'N','2024-07-03 23:22:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(79,3,3,1,22,1,22,13,1,1,1,'0','','','','','FHWWFV3','vistas/img/productos/varios/835.jpg',0,300.00,300.00,1,'N','2024-07-03 23:24:39','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(80,3,3,1,21,1,22,6,1,1,1,'0','','','','','DMB09N3','vistas/img/productos/varios/554.jpg',0,170.00,170.00,1,'N','2024-07-03 23:26:05','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(81,3,3,1,21,1,22,6,1,1,1,'0','','','','','HTW29N','vistas/img/productos/varios/908.jpg',0,170.00,170.00,1,'N','2024-07-03 23:34:04','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(82,3,3,1,22,1,22,13,1,1,1,'0','','','','','67PVVFV3','vistas/img/productos/varios/573.jpg',0,300.00,300.00,1,'N','2024-07-03 23:36:01','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(83,3,3,1,1,1,22,1,1,1,1,'0','','','','','1GL0VW3','vistas/img/productos/varios/867.jpg',0,1000.00,1000.00,1,'N','2024-07-03 23:37:50','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(84,3,3,1,22,1,22,13,1,1,1,'0','','','','','3B0QKT3','vistas/img/productos/varios/905.jpg',0,300.00,300.00,1,'N','2024-07-03 23:42:45','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(85,3,3,1,21,1,22,6,1,1,1,'0','','','','','30C09N3','vistas/img/productos/varios/375.jpg',0,170.00,170.00,1,'N','2024-07-03 23:44:17','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(86,3,3,1,21,1,22,6,1,1,1,'0','','','','','128Q9N3','vistas/img/productos/varios/894.jpg',0,170.00,170.00,1,'N','2024-07-03 23:51:22','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(87,3,3,1,21,1,22,6,1,1,1,'0','','','','','DPGF9N3','vistas/img/productos/varios/672.jpg',0,170.00,170.00,1,'N','2024-07-03 23:52:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(88,3,3,1,22,1,22,13,1,1,1,'0','','','','','CVVWFV3','vistas/img/productos/varios/842.jpg',0,300.00,300.00,1,'N','2024-07-03 23:54:38','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(89,3,3,1,1,1,22,1,1,1,1,'0','','','','','6TR0VW3','vistas/img/productos/varios/514.jpg',0,1000.00,1000.00,1,'N','2024-07-04 00:01:01','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(90,3,3,1,22,1,22,13,1,1,1,'0','','','','','JRSPKT3','vistas/img/productos/varios/491.jpg',0,300.00,300.00,1,'N','2024-07-04 00:15:02','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(91,3,3,1,21,1,22,6,1,1,1,'0','','','','','GWGF9N3','vistas/img/productos/varios/780.jpg',0,170.00,170.00,1,'N','2024-07-04 00:19:18','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(92,3,3,1,1,1,22,1,1,1,1,'0','','','','','73F0VW3','vistas/img/productos/varios/510.jpg',0,1000.00,1000.00,1,'N','2024-07-04 00:21:52','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(93,3,3,1,22,1,22,13,1,1,1,'0','','','','','H0YPKT3','vistas/img/productos/varios/401.jpg',0,300.00,300.00,1,'N','2024-07-04 00:24:42','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(94,3,3,1,1,1,22,1,36,1,1,'0','','','','','98VYTW3','vistas/img/productos/varios/967.jpg',0,1000.00,1000.00,1,'N','2024-07-04 00:45:17','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(95,3,3,1,1,1,22,1,48,1,1,'0','','','','','3CVK5X3','vistas/img/productos/varios/983.jpg',0,1148.00,1146.00,1,'N','2024-07-04 00:58:51','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(96,3,3,1,1,1,23,1,49,1,1,'0','','','','','74DL5X3','vistas/img/productos/varios/264.jpg',0,1148.00,1148.00,1,'N','2024-07-08 04:16:22','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(97,3,3,1,1,1,24,1,50,1,1,'0','','','','','CTNK5X3','vistas/img/productos/varios/505.jpg',0,1148.00,1148.00,1,'N','2024-07-08 04:30:00','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(98,3,3,1,1,1,25,1,51,1,1,'0','','','','','3XVK5X3','vistas/img/productos/varios/396.jpg',0,1148.00,1148.00,1,'N','2024-07-08 04:40:16','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(99,3,3,1,1,1,21,1,52,1,1,'0','','','','MXESL15016','CC4K5X3','vistas/img/productos/varios/867.jpg',0,1148.00,1148.00,1,'N','2024-07-08 04:48:43','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(100,3,3,1,1,1,26,1,53,1,1,'0','','','','MXESL15017','HLKL5X3','vistas/img/productos/varios/284.jpg',0,1148.00,1148.00,1,'N','2024-07-08 04:54:34','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(101,5,3,1,9,7,3,2,27,1,1,'0','','','','MXDCXXWWX3','CXXWWX3','vistas/img/productos/varios/551.jpg',0,800.00,797.00,2,'N','2024-07-09 03:05:29','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'3'),(102,5,3,3,19,7,3,3,27,1,1,'0','','60:95:32:00:8B:8E','','','T3J231702680','vistas/img/productos/varios/947.jpg',0,2000.00,2000.00,1,'N','2024-07-09 03:45:47','NO Aplica','10.107.71.56','',NULL,'','',NULL,'','','','','','','',NULL,'3'),(103,5,3,2,4,1,3,3,27,1,1,'0','','7C:57:58:2C:7E8:1','','','PHCCR2604Y','vistas/img/productos/varios/808.jpg',0,550.00,542.00,1,'N','2024-07-09 03:57:23','NO Aplica','10.107.71.11','',NULL,'','',NULL,'','','','','','','',NULL,''),(104,3,1,5,24,1,8,8,26,1,1,'6631053709','','','352580672777278','','352580672777278','vistas/img/productos/varios/895.jpg',0,250.00,250.00,1,'N','2024-07-09 04:05:14','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(105,3,1,5,24,1,30,8,54,1,1,'6631071885','','','352580672780652','','352580672780652','vistas/img/productos/varios/449.jpg',0,250.00,250.00,1,'N','2024-07-09 04:20:11','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(106,3,1,5,24,1,3,8,55,1,1,'6631070155','','','35280672814261','','35280672814261','vistas/img/productos/varios/844.jpg',0,250.00,250.00,1,'N','2024-07-09 04:29:22','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(107,3,1,5,24,1,3,8,50,1,1,'6631070951','','','352580672814055','','352580672814055','vistas/img/productos/varios/870.jpg',0,250.00,250.00,1,'N','2024-07-09 04:32:38','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(108,3,1,5,24,1,25,8,51,1,1,'6631047829','','','355611435235093','','355611435235093','vistas/img/productos/varios/256.jpg',0,250.00,250.00,1,'N','2024-07-09 04:36:17','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(109,3,1,5,24,1,3,8,52,1,1,'6601070944','','','352580672812026','','352580672812026','vistas/img/productos/varios/299.jpg',0,250.00,250.00,1,'N','2024-07-09 04:39:38','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(110,3,1,5,24,1,31,8,56,1,1,'6634079455','','','352295695947648','','352295695947648','vistas/img/productos/varios/700.jpg',0,250.00,250.00,1,'N','2024-07-09 04:52:03','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(111,3,1,5,13,1,3,8,57,1,1,'6634079451','','','352295695947820','','ZY22HLSHTG','vistas/img/productos/varios/420.jpg',0,250.00,250.00,1,'N','2024-07-09 05:02:42','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(112,3,1,5,24,1,17,8,58,1,1,'6631047609','','','355611435240846','','355611435240846','vistas/img/productos/varios/781.jpg',0,250.00,250.00,1,'N','2024-07-09 05:12:40','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(113,3,3,1,9,7,3,2,1,1,1,'0','','','','','JWXWWX3','vistas/img/productos/varios/573.jpg',1,800.00,800.00,NULL,'N','2024-07-09 19:50:34','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'5'),(114,5,1,3,25,7,3,3,1,1,1,'0','','T3J231702672','','','T3J231702672','vistas/img/productos/varios/311.jpg',1,2000.00,2000.00,NULL,'N','2024-07-09 19:56:24','NO Aplica','10.107.71.43','',NULL,'','',NULL,'','','','','','','',NULL,'5'),(115,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240M1J','vistas/img/productos/varios/248.jpg',1,120.00,120.00,NULL,'N','2024-07-09 21:25:09','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(116,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240M1B','vistas/img/productos/varios/623.jpg',1,120.00,120.00,NULL,'N','2024-07-09 21:27:40','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(117,3,3,2,4,1,22,3,1,1,1,'0','','','','','PHCCR2604P','vistas/img/productos/varios/560.jpg',1,550.00,550.00,NULL,'N','2024-07-09 23:24:08','NO Aplica','10.107.71.62','',NULL,'','',NULL,'','','','','','','',NULL,''),(118,3,3,1,21,1,22,6,1,1,1,'0','','','','','8ZGF9N3','vistas/img/productos/varios/942.jpg',1,200.00,200.00,NULL,'N','2024-07-10 00:26:48','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(119,3,3,1,21,1,22,6,1,1,1,'0','','','','','8C21B14','vistas/img/productos/varios/173.jpg',1,200.00,200.00,NULL,'N','2024-07-10 00:28:07','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(120,3,3,1,21,1,22,6,1,1,1,'0','','','','','8C41B14','vistas/img/productos/varios/880.jpg',1,200.00,200.00,NULL,'N','2024-07-10 00:29:25','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(121,3,3,1,9,1,22,2,1,1,1,'0','','','','MXDBJ97G24','BJ97G24','vistas/img/productos/varios/392.jpg',1,800.00,800.00,NULL,'N','2024-07-10 00:36:12','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(122,3,3,1,9,1,22,2,1,1,1,'0','','','','','FZ35D14','vistas/img/productos/varios/165.jpg',1,800.00,800.00,NULL,'N','2024-07-10 00:37:23','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(123,3,3,1,9,1,22,2,1,1,1,'0','','','','MXDJF67G24','JF67G24','vistas/img/productos/varios/164.jpg',1,800.00,800.00,NULL,'N','2024-07-10 00:38:51','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(124,3,3,1,9,1,22,2,1,1,1,'0','','','','MXD9J97G24','9J97G24','vistas/img/productos/varios/526.jpg',1,800.00,800.00,NULL,'N','2024-07-10 01:57:53','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(125,3,3,1,9,1,22,2,1,1,1,'0','','','','MXD5J97G24','5J97G24','vistas/img/productos/varios/903.jpg',1,800.00,800.00,NULL,'N','2024-07-10 01:59:01','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(126,3,3,1,9,1,22,2,1,1,1,'0','','','','MXDJG67G24','JG67G24','vistas/img/productos/varios/484.jpg',1,800.00,800.00,NULL,'N','2024-07-10 02:00:02','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(127,3,3,1,35,1,3,1,55,1,1,'0','','','','','9LSC1T3','vistas/img/productos/varios/923.jpg',0,1000.00,1000.00,1,'N','2024-07-10 04:19:53','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(128,3,3,1,1,1,8,1,60,1,1,'0','','','','','HGWYGY3','vistas/img/productos/varios/410.jpg',0,1000.00,1000.00,1,'N','2024-07-10 04:32:36','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(129,3,3,1,1,1,17,1,61,1,1,'0','','','','','57L0VW3','vistas/img/productos/varios/150.jpg',0,1000.00,1000.00,1,'N','2024-07-10 04:47:54','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(130,3,3,1,1,1,12,1,62,1,1,'0','','','','','43F0VW3','vistas/img/productos/varios/370.jpg',0,1000.00,1000.00,1,'N','2024-07-10 04:55:10','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(131,3,1,5,13,1,17,8,63,1,1,'6634079459','','','352295695945212','','ZY22HLSHST','vistas/img/productos/varios/792.jpg',0,250.00,250.00,1,'N','2024-07-10 05:02:30','Asignado','','',NULL,'','',NULL,'','','','','','','',NULL,''),(132,3,3,1,36,1,17,1,58,1,1,'0','','','','','93111113191','vistas/img/productos/varios/562.jpg',0,2139.00,2139.00,1,'N','2024-07-10 05:10:07','NO Aplica','','Service Tag : 49ZLGX3',NULL,'','',NULL,'','','','','','','',NULL,''),(133,3,3,1,36,1,17,1,41,1,1,'0','','','','','28902154215','vistas/img/productos/varios/242.jpg',0,2139.00,2139.00,1,'N','2024-07-10 05:16:32','NO Aplica','','Service Tag : D9ZLGX3',NULL,'','',NULL,'','','','','','','',NULL,''),(134,3,3,1,1,1,3,1,22,1,1,'0','','','','MXESL15026','FHJD5X3','vistas/img/productos/varios/890.jpg',0,1148.00,1148.00,1,'N','2024-07-10 05:20:06','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(135,3,3,1,1,1,21,1,64,1,1,'0','','','','MXESL15046','DGJJQN3','vistas/img/productos/varios/533.jpg',0,1148.00,1148.00,1,'N','2024-07-10 05:29:39','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(136,3,3,1,1,1,33,1,65,1,1,'0','','','','','HYD0VW3','vistas/img/productos/varios/751.jpg',0,1000.00,1000.00,1,'N','2024-07-10 05:37:36','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(137,3,3,1,1,1,8,1,66,1,1,'0','','','','','92F0VW3','vistas/img/productos/varios/687.jpg',0,1000.00,1000.00,1,'N','2024-07-10 05:45:01','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(141,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240M1G','vistas/img/productos/default/anonymous.png',1,0.00,0.00,NULL,'N','2024-07-11 13:09:46','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(142,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007857','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:17:02','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(143,3,3,2,34,1,22,3,1,1,1,'0','','','','','PHBCR54039','vistas/img/productos/default/anonymous.png',1,2300.00,2300.00,NULL,'N','2024-07-11 22:56:12','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(144,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240LXM','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(145,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240LTN','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(146,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240M1F','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(147,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240LTL','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(148,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M7Q','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(149,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240LRX','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(150,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240LZ7','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(151,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240LVK','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(152,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240LUF','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(153,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240LUD','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(154,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240LVP','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(155,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240LUY','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(156,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240LT3','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(157,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M1V','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(158,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M7W','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(159,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M86','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(160,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M85','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(161,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M7Y','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(162,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M80','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(163,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M87','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(164,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M8B','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(165,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M7U','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(166,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240MYT','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(167,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M8D','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(168,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240MYV','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(169,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M7O','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(170,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M7S','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(171,3,3,1,37,1,22,17,1,1,1,'0','','','','','A240M8F','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(172,3,3,1,27,1,22,17,1,1,1,'0','','','','','A240LM6','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(173,3,3,1,27,1,22,17,1,1,1,'0','','','','','A240LV8','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(174,3,3,1,27,1,22,17,1,1,1,'0','','','','','A240LVG','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(175,3,3,1,27,1,22,17,1,1,1,'0','','','','','A240M1D','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(176,3,3,1,27,1,22,17,1,1,1,'0','','','','','A240LVA','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(177,3,3,1,27,1,22,17,1,1,1,'0','','','','','A240LVE','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(178,3,3,1,27,1,22,17,1,1,1,'0','','','','','A240LM4','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(179,3,3,1,27,1,22,17,1,1,1,'0','','','','','A240LV4','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(180,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240M1P','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(181,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240LTP','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(182,3,3,1,26,1,22,15,1,1,1,'0','','','','','A240LTJ','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(183,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007967','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(184,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007980','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(185,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007977','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(186,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008044','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(187,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008045','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(188,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007968','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(189,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008012','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(190,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008039','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(191,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008043','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(192,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008008','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(193,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008024','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(194,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008034','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(195,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007898','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(196,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008020','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(197,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008041','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(198,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007859','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(199,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007894','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(200,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007965','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(201,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007903','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(202,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007957','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(203,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007969','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(204,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007966','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(205,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008040','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(206,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008046','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(207,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008036','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(208,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008038','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(209,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008028','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(210,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008033','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(211,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008019','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(212,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008032','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(213,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007900','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(214,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233008037','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(215,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007963','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(216,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007962','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(217,3,3,13,29,1,22,18,1,1,1,'0','','','','','J233007964','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(218,3,3,13,29,1,22,18,1,1,1,'0','','','','','HKJD5AU0SJ3','vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(219,3,3,1,22,1,22,15,1,1,1,'0','','','','','9WHPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(220,3,3,1,22,1,22,15,1,1,1,'0','','','','','DB0QKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(221,3,3,1,22,1,22,15,1,1,1,'0','','','','','D50QKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(222,3,3,1,22,1,22,15,1,1,1,'0','','','','','4PKPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(223,3,3,1,22,1,22,15,1,1,1,'0','','','','','DZVPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(224,3,3,1,22,1,22,15,1,1,1,'0','','','','','48MPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(225,3,3,1,22,1,22,15,1,1,1,'0','','','','','FJQPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(226,3,3,1,22,1,22,15,1,1,1,'0','','','','','DRNPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(227,3,3,1,22,1,22,15,1,1,1,'0','','','','','F1PPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(228,3,3,1,22,1,22,15,1,1,1,'0','','','','','1TSPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(229,3,3,1,22,1,22,15,1,1,1,'0','','','','','9LSPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(230,3,3,1,22,1,22,15,1,1,1,'0','','','','','H0PPKT3','vistas/img/productos/default/anonymous.png',1,200.00,200.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(231,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2348L37621','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(232,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2348L37618','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(233,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2348L37610','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(234,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2348L36976','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(235,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2402L53466','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(236,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2348L37574','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(237,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2348L37611','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(238,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2402L53375','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(239,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2402L50568','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(240,3,3,14,38,1,22,19,1,1,1,'0','','','','','S0B2348L37226','vistas/img/productos/default/anonymous.png',1,220.00,220.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(241,3,3,1,31,1,22,21,1,1,1,'0','','','','','PRC00-378-04VC-A04','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(242,3,3,1,31,1,22,21,1,1,1,'0','','','','','PRC00-34K-00FG-A03','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(243,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0CJA02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(244,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0CRA02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(245,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0FAA02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(246,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0COA02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(247,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0F1A02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:55','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(248,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0F9A02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(249,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0F4A02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(250,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0F2A02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(251,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0F8A02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(252,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0F5A02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(253,3,3,1,32,1,22,22,1,1,1,'0','','','','','CN01KMDJLO3003B8B0F3A02','vistas/img/productos/default/anonymous.png',1,20.00,20.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(254,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N02LJ','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(255,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N02NF','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(256,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO300316G8WP','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(257,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN005MTHPRC002ATA27R','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(258,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO300316G74N','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(259,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN0081N8LO30038SA55T','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(260,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN0081N8LO30038SA63J','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(261,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N02LI','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(262,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00D7','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(263,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00D9','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(264,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041U05X8','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(265,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N02H7','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(266,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00GV','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(267,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00GU','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(268,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00EQ','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(269,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO3003AE0MKZ','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(270,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N02NE','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(271,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00GR','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(272,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N02H8','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(273,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO3003AE0KSW','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(274,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO3003AN0EC1','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(275,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN005MTHPRC00331A24M','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(276,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N02ND','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(277,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N02NL','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(278,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00EK','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(279,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00GP','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(280,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00EO','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(281,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N02NK','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(282,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00DB','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(283,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00DA','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(284,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00D6','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(285,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN005MTHPRC002ATA27N','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(286,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00EI','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(287,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041U05X1','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(288,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00EM','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(289,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041U05X3','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(290,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00GT','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(291,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00DC','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(292,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO3003AE0KSM','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(293,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO3003AE0MOU','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(294,3,3,1,7,1,22,4,1,1,1,'0','','','','','CN019M93LO30041N00EN','vistas/img/productos/default/anonymous.png',1,10.00,10.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(295,3,3,15,33,1,22,23,1,1,1,'0','','','','','2333ALA00KK9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(296,3,3,15,33,1,22,23,1,1,1,'0','','','','','2333ALA00KH9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(297,3,3,15,33,1,22,23,1,1,1,'0','','','','','2331ALA02XT9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(298,3,3,15,33,1,22,23,1,1,1,'0','','','','','2333ALA00C49','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(299,3,3,15,33,1,22,23,1,1,1,'0','','','','','2121ALA04P49','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(300,3,3,15,33,1,22,23,1,1,1,'0','','','','','2121ALA05A59','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(301,3,3,15,33,1,22,23,1,1,1,'0','','','','','2331ALA038M9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(302,3,3,15,33,1,22,23,1,1,1,'0','','','','','2121ALA04HM9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(303,3,3,15,33,1,22,23,1,1,1,'0','','','','','2112ALA08KY9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(304,3,3,15,33,1,22,23,1,1,1,'0','','','','','2121ALA04JE9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(305,3,3,15,33,1,22,23,1,1,1,'0','','','','','2333ALA00A39','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(306,3,3,15,33,1,22,23,1,1,1,'0','','','','','2333ALA005P9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(307,3,3,15,33,1,22,23,1,1,1,'0','','','','','2333ALA00BT9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(308,3,3,15,33,1,22,23,1,1,1,'0','','','','','2331ALA03S09','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(309,3,3,15,33,1,22,23,1,1,1,'0','','','','','2121ALA04JF9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(310,3,3,15,33,1,22,23,1,1,1,'0','','','','','2331ALA03BV9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(311,3,3,15,33,1,22,23,1,1,1,'0','','','','','2333ALA00A19','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(312,3,3,15,33,1,22,23,1,1,1,'0','','','','','2331ALA03FL9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(313,3,3,15,33,1,22,23,1,1,1,'0','','','','','2333ALA00KU9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(314,3,3,15,33,1,22,23,1,1,1,'0','','','','','2331ALA03DF9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(315,3,3,15,33,1,22,23,1,1,1,'0','','','','','2331ALA03BW9','vistas/img/productos/default/anonymous.png',1,30.00,30.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(316,3,3,2,4,1,22,3,1,1,1,'0','','','','','PHCCS4S117','vistas/img/productos/default/anonymous.png',1,450.00,450.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(317,3,3,2,4,1,22,3,1,1,1,'0','','','','','PHCCS4S11H','vistas/img/productos/default/anonymous.png',1,450.00,450.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(318,3,3,2,34,1,22,3,1,1,1,'0','','','','','PHBCR520QP','vistas/img/productos/default/anonymous.png',1,2300.00,2300.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(319,3,3,2,34,1,22,3,1,1,1,'0','','','','','PHBCR520QL','vistas/img/productos/default/anonymous.png',1,2300.00,2300.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(320,3,3,2,34,1,22,3,1,1,1,'0','','','','','PHBCR520R5','vistas/img/productos/default/anonymous.png',1,2300.00,2300.00,NULL,'N','2024-07-11 22:57:56','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(321,3,3,1,28,1,22,24,1,1,1,'0','','','','','A240P22','vistas/img/productos/default/anonymous.png',1,40.00,40.00,NULL,'N','2024-07-11 23:01:28','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(322,3,3,1,28,1,22,24,1,1,1,'0','','','','','A240PDG','vistas/img/productos/default/anonymous.png',1,40.00,40.00,NULL,'N','2024-07-11 23:01:28','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(323,3,3,1,28,1,22,24,1,1,1,'0','','','','','A240P05','vistas/img/productos/default/anonymous.png',1,40.00,40.00,NULL,'N','2024-07-11 23:01:28','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(324,3,3,1,28,1,22,24,1,1,1,'0','','','','','A240PDO','vistas/img/productos/default/anonymous.png',1,40.00,40.00,NULL,'N','2024-07-11 23:01:28','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(325,3,3,1,28,1,22,24,1,1,1,'0','','','','','A240PEN','vistas/img/productos/default/anonymous.png',1,40.00,40.00,NULL,'N','2024-07-11 23:01:28','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(326,3,3,1,28,1,22,24,1,1,1,'0','','','','','A240P04','vistas/img/productos/default/anonymous.png',1,40.00,40.00,NULL,'N','2024-07-11 23:01:28','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(327,3,3,1,28,1,22,24,1,1,1,'0','','','','','A240PDD','vistas/img/productos/default/anonymous.png',1,40.00,40.00,NULL,'N','2024-07-11 23:01:28','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(328,3,3,1,28,1,22,24,1,1,1,'0','','','','','A240PCW','vistas/img/productos/default/anonymous.png',1,40.00,40.00,NULL,'N','2024-07-11 23:01:28','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,''),(329,3,3,1,28,1,22,24,1,1,1,'0','','','','','A240P7D','vistas/img/productos/default/anonymous.png',1,40.00,40.00,NULL,'N','2024-07-11 23:01:28','NO Aplica','','',NULL,'','',NULL,'','','','','','','',NULL,'');
/*!40000 ALTER TABLE `t_Productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Puesto`
--

DROP TABLE IF EXISTS `t_Puesto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Puesto` (
  `id_puesto` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  PRIMARY KEY (`id_puesto`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Puesto`
--

LOCK TABLES `t_Puesto` WRITE;
/*!40000 ALTER TABLE `t_Puesto` DISABLE KEYS */;
INSERT INTO `t_Puesto` VALUES (1,'Soporte De EHS'),(2,'N/A'),(3,'Tecnico de Mantenimiento'),(4,'Logistics Analyst Jr'),(5,'Director de Ingenieria de Manufactura'),(6,'RH Interno'),(7,'Linea Produccion'),(8,'Distribution Center Manager'),(9,'Supervisor'),(10,'Especialista Recursos Humanos'),(11,'Purchasing Assistant'),(12,'Laborlist Special HR'),(13,'Distribution Center Director'),(14,'Tool Maker'),(15,'Customer Service Analyst'),(16,'Coating Station'),(17,'NSL NPI Manager'),(18,'EHS ENGINEER'),(19,'Gerente De Compras'),(20,'Gerente General'),(21,'Supervisor Nominas'),(22,'Gerente Sr. Activos Fijos'),(23,'Contador General'),(24,'Analista RH'),(25,'Moldeo - Oakley'),(26,'Analista Planeacion'),(27,'Ingeniero de Calidad'),(28,'Coordinador Asset Proctection'),(29,'Analista Simulacion Jr'),(30,'Gerente Cadena Suministros '),(31,'Gerente Sr. Opex y Aumatizacion'),(32,'Gerente de Calidad'),(33,'Supervisor Customer Service'),(34,'Asistente Administrativo'),(35,'Gerente Centro Distribucion'),(36,'Supervisor Finishing'),(37,'Supervisor Mantenimientol'),(38,'Hr Business Partner'),(39,'Gerente Ingeniero de Procesos'),(40,'Coordinador Entrenamiento');
/*!40000 ALTER TABLE `t_Puesto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Rep_Finanzas`
--

DROP TABLE IF EXISTS `t_Rep_Finanzas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Rep_Finanzas` (
  `id_rep_finanzas` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `ntid` varchar(20) DEFAULT NULL,
  `fecha_asignado` date DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellidos` varchar(45) DEFAULT NULL,
  `num_centro_costos` varchar(30) DEFAULT NULL,
  `descrip_depto` varchar(50) DEFAULT NULL,
  `periferico` varchar(80) DEFAULT NULL,
  `marca` varchar(45) DEFAULT NULL,
  `modelo` varchar(45) DEFAULT NULL,
  `num_serial` varchar(45) DEFAULT NULL,
  `precio_compra` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_rep_finanzas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Rep_Finanzas`
--

LOCK TABLES `t_Rep_Finanzas` WRITE;
/*!40000 ALTER TABLE `t_Rep_Finanzas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_Rep_Finanzas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Responsivas`
--

DROP TABLE IF EXISTS `t_Responsivas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Responsivas` (
  `id_responsiva` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` smallint(5) unsigned NOT NULL,
  `id_usuario` smallint(5) unsigned NOT NULL,
  `id_almacen` smallint(5) unsigned NOT NULL,
  `activa` char(1) NOT NULL DEFAULT 'S',
  `num_folio` smallint(5) unsigned NOT NULL,
  `modalidad_entrega` varchar(25) NOT NULL,
  `num_ticket` varchar(30) DEFAULT NULL,
  `responsiva_firmada` varchar(100) DEFAULT NULL,
  `comentario` text DEFAULT NULL,
  `comentario_devolucion` text DEFAULT NULL,
  `productos` text DEFAULT NULL,
  `impuesto` decimal(10,2) DEFAULT NULL,
  `neto` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `fecha_devolucion` date DEFAULT NULL,
  `fecha_asignado` date DEFAULT NULL,
  PRIMARY KEY (`id_responsiva`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_almacen` (`id_almacen`),
  CONSTRAINT `t_Responsivas_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `t_Empleados` (`id_empleado`) ON UPDATE CASCADE,
  CONSTRAINT `t_Responsivas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `t_Usuarios` (`id_usuario`) ON UPDATE CASCADE,
  CONSTRAINT `t_Responsivas_ibfk_3` FOREIGN KEY (`id_almacen`) REFERENCES `t_Almacen` (`id_almacen`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Responsivas`
--

LOCK TABLES `t_Responsivas` WRITE;
/*!40000 ALTER TABLE `t_Responsivas` DISABLE KEYS */;
INSERT INTO `t_Responsivas` VALUES (1,6,1,1,'S',1,'Permanente','ad324s',NULL,'',NULL,'[{\"id\":\"3\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"800.00\",\"total\":\"800.00\"}]',0.00,800.00,800.00,NULL,'2024-04-11'),(2,10,2,1,'S',2,'Permanente','AS234',NULL,'',NULL,'[{\"id\":\"5\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"950.00\",\"total\":\"950.00\"}]',0.00,950.00,950.00,NULL,'2024-04-11'),(3,11,2,3,'S',3,'Permanente','',NULL,'',NULL,'[{\"id\":\"6\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"900.00\",\"total\":\"900.00\"}]',0.00,900.00,900.00,NULL,'2024-05-12'),(4,12,2,3,'S',4,'Permanente','',NULL,'',NULL,'[{\"id\":\"7\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-05-12'),(5,19,2,3,'S',5,'Permanente','',NULL,'',NULL,'[{\"id\":\"12\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-05-16'),(6,27,2,3,'S',6,'Permanente','',NULL,'',NULL,'[{\"id\":\"13\",\"descripcion\":\"Desktop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"500.00\",\"total\":\"500\"},{\"id\":\"16\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"120.00\",\"total\":\"120\"},{\"id\":\"14\",\"descripcion\":\"Teclado\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"10.00\",\"total\":\"10\"},{\"id\":\"15\",\"descripcion\":\"Raton\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"10.00\",\"total\":\"10\"},{\"id\":\"10\",\"descripcion\":\"Impresora\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"500.00\",\"total\":\"500.00\"},{\"id\":\"11\",\"descripcion\":\"Impresora\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"550.00\",\"total\":\"550.00\"},{\"id\":\"20\",\"descripcion\":\"Dispensador Cinta Para Cajas\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"2220.00\",\"total\":\"2220.00\"},{\"id\":\"30\",\"descripcion\":\"Pesa\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"800.00\",\"total\":\"800.00\"}]',0.00,4710.00,4710.00,NULL,'2023-08-31'),(7,21,2,4,'S',7,'Permanente','',NULL,'',NULL,'[{\"id\":\"18\",\"descripcion\":\"Maquina pulidora micas\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1.00\",\"total\":\"1.00\"}]',0.00,1.00,1.00,NULL,'2024-04-01'),(8,22,2,5,'S',8,'Permanente','',NULL,'',NULL,'[{\"id\":\"22\",\"descripcion\":\"Raton\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"5.00\",\"total\":\"5\"},{\"id\":\"19\",\"descripcion\":\"Desktop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"500.00\",\"total\":\"500\"},{\"id\":\"21\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"120.00\",\"total\":\"120.00\"},{\"id\":\"23\",\"descripcion\":\"Teclado\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"10.00\",\"total\":\"10.00\"},{\"id\":\"24\",\"descripcion\":\"Impresora\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"550.00\",\"total\":\"550.00\"},{\"id\":\"25\",\"descripcion\":\"Escaner Tipo Pistola\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"200.00\",\"total\":\"200.00\"}]',0.00,1385.00,1385.00,NULL,'2023-12-19'),(9,24,2,3,'S',9,'Permanente','',NULL,'',NULL,'[{\"id\":\"26\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"220.00\",\"total\":\"220.00\"}]',0.00,220.00,220.00,NULL,'2024-05-21'),(10,17,2,3,'S',10,'Permanente','',NULL,'',NULL,'[{\"id\":\"27\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"700.00\",\"total\":\"700.00\"}]',0.00,700.00,700.00,NULL,'2024-05-20'),(11,25,2,3,'S',11,'Permanente','',NULL,'',NULL,'[{\"id\":\"28\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-05-20'),(12,17,2,3,'S',12,'Permanente','',NULL,'',NULL,'[{\"id\":\"29\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-05-20'),(13,27,2,5,'S',13,'Permanente','',NULL,'',NULL,'[{\"id\":\"31\",\"descripcion\":\"Escaner\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"380.00\",\"total\":\"380\"},{\"id\":\"32\",\"descripcion\":\"Impresora\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"8000.00\",\"total\":\"8000\"},{\"id\":\"33\",\"descripcion\":\"Desktop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"500.00\",\"total\":\"500\"},{\"id\":\"34\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"120.00\",\"total\":\"120\"},{\"id\":\"35\",\"descripcion\":\"Teclado\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"10.00\",\"total\":\"10\"},{\"id\":\"36\",\"descripcion\":\"Raton\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"5.00\",\"total\":\"5.00\"}]',0.00,9015.00,9015.00,NULL,'2023-08-01'),(14,27,2,5,'S',14,'Permanente','',NULL,'',NULL,'[{\"id\":\"37\",\"descripcion\":\"Impresora\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"8000.00\",\"total\":\"8000\"},{\"id\":\"38\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"120.00\",\"total\":\"120\"},{\"id\":\"39\",\"descripcion\":\"Desktop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"500.00\",\"total\":\"500\"},{\"id\":\"41\",\"descripcion\":\"Raton\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"5.00\",\"total\":\"5\"},{\"id\":\"42\",\"descripcion\":\"Escaner\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"380.00\",\"total\":\"380\"}]',0.00,9005.00,9005.00,NULL,'2023-08-01'),(15,28,2,3,'S',15,'Permanente','',NULL,'',NULL,'[{\"id\":\"45\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-06-03'),(16,29,2,3,'S',16,'Permanente','',NULL,'',NULL,'[{\"id\":\"46\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2024-10-02'),(17,30,2,3,'S',17,'Permanente','',NULL,'',NULL,'[{\"id\":\"47\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2023-12-07'),(18,32,2,3,'S',18,'Permanente','',NULL,'',NULL,'[{\"id\":\"48\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-08-08'),(19,33,2,3,'S',19,'Permanente','',NULL,'',NULL,'[{\"id\":\"49\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-08-17'),(20,35,2,3,'S',20,'Permanente','',NULL,'',NULL,'[{\"id\":\"51\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-02-09'),(21,36,2,3,'S',21,'Permanente','',NULL,'',NULL,'[{\"id\":\"52\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-06-21'),(22,26,2,3,'S',22,'Permanente','',NULL,'',NULL,'[{\"id\":\"53\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"4309.48\",\"total\":\"4309.48\"}]',0.00,4309.48,4309.48,NULL,'2024-05-06'),(23,37,2,3,'S',23,'Permanente','',NULL,'',NULL,'[{\"id\":\"54\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-05-03'),(24,38,2,3,'S',24,'Permanente','',NULL,'',NULL,'[{\"id\":\"55\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-05-02'),(25,40,2,3,'S',25,'Permanente','',NULL,'',NULL,'[{\"id\":\"58\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-05-28'),(26,40,2,3,'S',26,'Permanente','',NULL,'Jun/19/24:\r\nSe regresa laptop 98HK5X3, se asigna nuevamente BTD0VW3.\r\n\r\nFue entregada por : \r\n              Ramon Ortega',NULL,'[{\"id\":\"57\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-06-11'),(27,41,2,3,'S',27,'Permanente','',NULL,'',NULL,'[{\"id\":\"59\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"20688.79\",\"total\":\"20688.79\"}]',0.00,20688.79,20688.79,NULL,'2024-05-09'),(28,42,2,3,'S',28,'Permanente','',NULL,'',NULL,'[{\"id\":\"60\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-06-24'),(29,43,2,3,'S',29,'Permanente','',NULL,'',NULL,'[{\"id\":\"61\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-06-25'),(30,44,2,3,'S',30,'Permanente','',NULL,'',NULL,'[{\"id\":\"63\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"240.00\",\"total\":\"240.00\"}]',0.00,240.00,240.00,NULL,'2024-04-29'),(31,44,2,3,'S',31,'Permanente','',NULL,'',NULL,'[{\"id\":\"62\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-04-29'),(32,45,2,3,'S',32,'Permanente','',NULL,'',NULL,'[{\"id\":\"64\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"843.00\",\"total\":\"843.00\"}]',0.00,843.00,843.00,NULL,'2024-04-22'),(33,41,2,3,'S',33,'Permanente','',NULL,'',NULL,'[{\"id\":\"65\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-04-22'),(34,46,2,3,'S',34,'Permanente','',NULL,'',NULL,'[{\"id\":\"66\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"850.00\",\"total\":\"850.00\"}]',0.00,850.00,850.00,NULL,'2024-04-23'),(35,47,2,3,'S',35,'Permanente','',NULL,'',NULL,'[{\"id\":\"67\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-04-18'),(36,1,2,3,'S',36,'Permanente','',NULL,'',NULL,'[{\"id\":\"68\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170\"},{\"id\":\"89\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000\"},{\"id\":\"90\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300.00\"}]',0.00,1470.00,1470.00,NULL,'2023-08-03'),(37,1,2,3,'S',37,'Permanente','',NULL,'',NULL,'[{\"id\":\"69\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170\"},{\"id\":\"70\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"230.00\",\"total\":\"230.00\"}]',0.00,400.00,400.00,NULL,'2023-08-03'),(38,1,2,3,'S',38,'Permanente','',NULL,'',NULL,'[{\"id\":\"71\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"230.00\",\"total\":\"230\"},{\"id\":\"72\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170.00\"}]',0.00,400.00,400.00,NULL,'2023-08-01'),(39,1,2,3,'S',39,'Permanente','',NULL,'',NULL,'[{\"id\":\"73\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300\"},{\"id\":\"74\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"180.00\",\"total\":\"180.00\"}]',0.00,480.00,480.00,NULL,'2023-08-01'),(40,1,2,3,'S',40,'Permanente','',NULL,'',NULL,'[{\"id\":\"75\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170\"},{\"id\":\"76\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300.00\"}]',0.00,470.00,470.00,NULL,'2023-08-01'),(41,1,2,3,'S',41,'Permanente','',NULL,'',NULL,'[{\"id\":\"78\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000\"},{\"id\":\"79\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300\"},{\"id\":\"80\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170.00\"}]',0.00,1470.00,1470.00,NULL,'0203-03-08'),(42,1,2,3,'S',42,'Permanente','',NULL,'',NULL,'[{\"id\":\"81\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170\"},{\"id\":\"82\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300\"},{\"id\":\"83\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1470.00,1470.00,NULL,'2023-08-01'),(43,1,2,3,'S',43,'Permanente','',NULL,'',NULL,'[{\"id\":\"84\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300\"},{\"id\":\"85\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170.00\"}]',0.00,470.00,470.00,NULL,'2023-08-01'),(44,1,2,3,'S',44,'Permanente','',NULL,'',NULL,'[{\"id\":\"86\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170\"},{\"id\":\"87\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170\"},{\"id\":\"88\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300.00\"}]',0.00,640.00,640.00,NULL,'2023-08-01'),(45,1,2,3,'S',45,'Permanente','',NULL,'',NULL,'[{\"id\":\"91\",\"descripcion\":\"Monitor\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"170.00\",\"total\":\"170\"},{\"id\":\"92\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000\"},{\"id\":\"93\",\"descripcion\":\"Docking Station\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300.00\"}]',0.00,1470.00,1470.00,NULL,'2023-08-01'),(46,36,2,3,'S',46,'Permanente','',NULL,'',NULL,'[{\"id\":\"94\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-06-21'),(47,34,2,3,'S',47,'Permanente','',NULL,'',NULL,'[{\"id\":\"50\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-09-01'),(48,48,2,3,'S',48,'Permanente','',NULL,'',NULL,'[{\"id\":\"95\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1146.00\",\"total\":\"1146.00\"}]',0.00,1146.00,1146.00,NULL,'2023-11-07'),(49,49,2,3,'S',49,'Permanente','',NULL,'',NULL,'[{\"id\":\"96\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-11-08'),(50,50,2,3,'S',50,'Permanente','',NULL,'',NULL,'[{\"id\":\"97\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-08-10'),(51,51,2,3,'S',51,'Permanente','',NULL,'',NULL,'[{\"id\":\"98\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-10-02'),(52,52,2,3,'S',52,'Permanente','',NULL,'',NULL,'[{\"id\":\"99\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-08-10'),(53,53,2,3,'S',53,'Permanente','',NULL,'',NULL,'[{\"id\":\"100\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-07-27'),(54,27,2,3,'S',54,'Permanente','',NULL,'',NULL,'[{\"id\":\"101\",\"descripcion\":\"Desktop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"797.00\",\"total\":\"797\"},{\"id\":\"102\",\"descripcion\":\"Impresora\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"2000.00\",\"total\":\"2000\"},{\"id\":\"103\",\"descripcion\":\"Impresora\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"542.00\",\"total\":\"542.00\"}]',0.00,3339.00,3339.00,NULL,'2023-08-01'),(55,26,2,3,'S',55,'Permanente','',NULL,'',NULL,'[{\"id\":\"104\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2023-12-07'),(56,54,2,3,'S',56,'Permanente','',NULL,'',NULL,'[{\"id\":\"105\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2023-08-02'),(57,55,2,3,'S',57,'Permanente','',NULL,'',NULL,'[{\"id\":\"106\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2023-08-17'),(58,50,2,3,'S',58,'Permanente','',NULL,'',NULL,'[{\"id\":\"107\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2023-08-17'),(59,51,2,3,'S',59,'Permanente','',NULL,'',NULL,'[{\"id\":\"108\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2023-10-02'),(60,52,2,3,'S',60,'Permanente','',NULL,'',NULL,'[{\"id\":\"109\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2023-08-17'),(61,56,2,3,'S',61,'Permanente','',NULL,'',NULL,'[{\"id\":\"110\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2024-03-05'),(62,57,2,3,'S',62,'Permanente','',NULL,'',NULL,'[{\"id\":\"111\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2024-05-05'),(63,58,2,3,'S',63,'Permanente','',NULL,'',NULL,'[{\"id\":\"112\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2023-08-17'),(64,55,2,3,'S',64,'Permanente','',NULL,'',NULL,'[{\"id\":\"127\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2023-08-01'),(65,60,2,3,'S',65,'Permanente','',NULL,'',NULL,'[{\"id\":\"128\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-03-02'),(66,61,2,3,'S',66,'Permanente','',NULL,'',NULL,'[{\"id\":\"129\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-03-03'),(67,62,2,3,'S',67,'Permanente','',NULL,'',NULL,'[{\"id\":\"130\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2023-03-09'),(68,63,2,3,'S',68,'Permanente','',NULL,'',NULL,'[{\"id\":\"131\",\"descripcion\":\"Telefono\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250.00\"}]',0.00,250.00,250.00,NULL,'2024-09-11'),(69,58,2,3,'S',69,'Permanente','',NULL,'',NULL,'[{\"id\":\"132\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"2139.00\",\"total\":\"2139.00\"}]',0.00,2139.00,2139.00,NULL,'2023-11-17'),(70,41,2,3,'S',70,'Permanente','',NULL,'',NULL,'[{\"id\":\"133\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"2139.00\",\"total\":\"2139.00\"}]',0.00,2139.00,2139.00,NULL,'2023-11-17'),(71,22,2,3,'S',71,'Permanente','',NULL,'',NULL,'[{\"id\":\"134\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-11-07'),(72,64,2,3,'S',72,'Permanente','',NULL,'',NULL,'[{\"id\":\"135\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1148.00\",\"total\":\"1148.00\"}]',0.00,1148.00,1148.00,NULL,'2023-09-29'),(73,65,2,3,'S',73,'Permanente','',NULL,'',NULL,'[{\"id\":\"136\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2024-03-01'),(74,66,2,3,'S',74,'Permanente','',NULL,'',NULL,'[{\"id\":\"137\",\"descripcion\":\"Laptop\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1000.00\",\"total\":\"1000.00\"}]',0.00,1000.00,1000.00,NULL,'2023-03-28');
/*!40000 ALTER TABLE `t_Responsivas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Supervisor`
--

DROP TABLE IF EXISTS `t_Supervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Supervisor` (
  `id_supervisor` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`id_supervisor`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Supervisor`
--

LOCK TABLES `t_Supervisor` WRITE;
/*!40000 ALTER TABLE `t_Supervisor` DISABLE KEYS */;
INSERT INTO `t_Supervisor` VALUES (1,'Benito Godinez'),(2,'N/A'),(3,'Wilmer Martinez'),(4,'Adrian Rodriguez'),(5,'Maribel Dominguez'),(6,'Supervisor RH'),(7,'Patricio Lechon'),(8,'Linea Produccion'),(9,'Jazmin Anai Ruelas'),(10,'Fernando Irazaba'),(12,'Enrique De Los Rios'),(13,'Angelica M Ramirez Caballero'),(14,'Supervisor Customer Service'),(15,'Supervisor Coating'),(16,'Supervisor Ingenieria'),(17,'Supervisor Compras'),(18,'Supervisor EHS'),(19,'Supervisor Gerente General'),(20,'Moises Beltran'),(21,'Ricky Tamburro'),(22,'Supervisor Finanzas'),(23,'Alejandro Flores'),(24,'Supervisor Planeacion'),(25,'Guadalupe Castro'),(26,'Jose Prieto Munoz'),(27,'Jacobo Valenzuela'),(28,'Supervisor Simulacion'),(29,'Supervisor Cadena Suministros'),(30,'Supervisor Opex y Automatizacion'),(31,'Gerente De Calidad'),(32,'Supervisor Facilities'),(33,'David Cervantes De La Vega'),(34,'Supervisor Asset Proteccion'),(35,'Supervisor Mantenimiento'),(37,'Supervisor Ingenieria Procesos'),(38,'Supervisor Entrenamiento'),(39,'Alicia Castro');
/*!40000 ALTER TABLE `t_Supervisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Tareas`
--

DROP TABLE IF EXISTS `t_Tareas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Tareas` (
  `id_tarea` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_estatus` smallint(5) unsigned NOT NULL,
  `id_usuario` smallint(5) unsigned NOT NULL,
  `id_empleado` smallint(5) unsigned NOT NULL,
  `id_categoria` smallint(5) unsigned NOT NULL,
  `id_ubicacion` smallint(5) unsigned NOT NULL,
  `tareas` varchar(120) DEFAULT NULL,
  `ticket` varchar(25) DEFAULT NULL,
  `fecha` date NOT NULL DEFAULT current_timestamp(),
  `comentarios` text DEFAULT NULL,
  PRIMARY KEY (`id_tarea`),
  KEY `id_estatus` (`id_estatus`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_ubicacion` (`id_ubicacion`),
  CONSTRAINT `t_Tareas_ibfk_1` FOREIGN KEY (`id_estatus`) REFERENCES `t_Estatus` (`id_estatus`) ON UPDATE CASCADE,
  CONSTRAINT `t_Tareas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `t_Usuarios` (`id_usuario`) ON UPDATE CASCADE,
  CONSTRAINT `t_Tareas_ibfk_3` FOREIGN KEY (`id_empleado`) REFERENCES `t_Empleados` (`id_empleado`) ON UPDATE CASCADE,
  CONSTRAINT `t_Tareas_ibfk_4` FOREIGN KEY (`id_categoria`) REFERENCES `t_Categorias` (`id_categoria`) ON UPDATE CASCADE,
  CONSTRAINT `t_Tareas_ibfk_5` FOREIGN KEY (`id_ubicacion`) REFERENCES `t_Ubicacion` (`id_ubicacion`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Tareas`
--

LOCK TABLES `t_Tareas` WRITE;
/*!40000 ALTER TABLE `t_Tareas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_Tareas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Telefonia`
--

DROP TABLE IF EXISTS `t_Telefonia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Telefonia` (
  `id_telefonia` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id_telefonia`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Telefonia`
--

LOCK TABLES `t_Telefonia` WRITE;
/*!40000 ALTER TABLE `t_Telefonia` DISABLE KEYS */;
INSERT INTO `t_Telefonia` VALUES (1,'Telcel');
/*!40000 ALTER TABLE `t_Telefonia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Ubicacion`
--

DROP TABLE IF EXISTS `t_Ubicacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Ubicacion` (
  `id_ubicacion` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_ubicacion`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Ubicacion`
--

LOCK TABLES `t_Ubicacion` WRITE;
/*!40000 ALTER TABLE `t_Ubicacion` DISABLE KEYS */;
INSERT INTO `t_Ubicacion` VALUES (3,'Distribution Center'),(4,'N/A'),(5,'Oakley Mantenimiento'),(6,'Oakley ELM'),(7,'LAB'),(8,'Oficinas R H'),(9,'DC Smart Table Estacion 6'),(10,'Surfacing'),(11,'Inbound - Recibos'),(12,'Ingenieria '),(13,'Purchasing'),(14,'Laboratorio'),(15,'Coating'),(16,'EHS'),(17,'Asset Protection'),(18,'Finanzas'),(19,'Oakley Moldeo'),(20,'Planeacion'),(21,'Calidad'),(22,'Sistemas - IT'),(23,'Simulacion'),(24,'Cadena Suministros'),(25,'Opex Automatizacion'),(26,'Customer Service'),(27,'VAS'),(30,'Facilities - Operaciones'),(31,'Finishing'),(32,'Mantenimiento DC'),(33,'Training  y CI');
/*!40000 ALTER TABLE `t_Ubicacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Usuarios`
--

DROP TABLE IF EXISTS `t_Usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Usuarios` (
  `id_usuario` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  `clave` varchar(80) NOT NULL,
  `perfil` varchar(45) NOT NULL,
  `vendedor` varchar(45) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `estado` tinyint(3) unsigned DEFAULT 0,
  `ultimo_login` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Usuarios`
--

LOCK TABLES `t_Usuarios` WRITE;
/*!40000 ALTER TABLE `t_Usuarios` DISABLE KEYS */;
INSERT INTO `t_Usuarios` VALUES (1,'Administrador','admin','Essilor-Resp-Mar04-2@24','Administrador',NULL,NULL,1,'2024-04-11 20:03:22','2024-03-10 17:25:47'),(2,'Ramon Ortega','Ramon','$2a$07$asxx54ahjppf45sd87a5au.pzxkSIR.Y/za2JS2AkQ3GHt/Gdy6JG','Administrador',NULL,'vistas/img/usuarios/Ramon/971.jpg',1,'2024-07-11 19:58:41','2024-04-11 11:28:45');
/*!40000 ALTER TABLE `t_Usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-13  4:30:01
